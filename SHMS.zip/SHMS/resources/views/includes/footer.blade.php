
    <div class="app-footer">
        <div class="footer-bottom  pt-3 d-flex flex-column flex-sm-row align-items-center">
            <span class="flex-grow-1"></span>
            <div class="d-flex align-items-center">
                <div>
                    <p class="m-0">&copy; SHMS 2020</p>
                    <p class="m-0">All rights reserved</p>
                </div>
            </div>
        </div>
    </div>
